<html>
    <p>Pagina de baja una cochera</p>
    </html>