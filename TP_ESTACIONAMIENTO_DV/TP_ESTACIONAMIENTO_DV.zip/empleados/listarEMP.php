<html>
    <p>Pagina de informe empleados</p>
    <br><br>
    <p>LAPSO DE TIEMPO (DESDE/HASTA)
                        EMPLEADOS
                                CHECK IN - OUT
                                        DIA
                                        HORARIO
                                        CANT HORAS
                                OPERACIONES      (T)
                                        CANTIDAD
</p>
    </html>